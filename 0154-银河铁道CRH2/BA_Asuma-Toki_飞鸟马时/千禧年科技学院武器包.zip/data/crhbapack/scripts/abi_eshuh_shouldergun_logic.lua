local M = {}

function M.shoot(api)
    local SEMI_MODE = SEMI
    local BURST_MODE = BURST
    
    local currentMode = api:getFireMode()

    if currentMode == SEMI_MODE then
        api:shootOnce(true) 
    end

    if currentMode == BURST_MODE then
        api:safeAsyncTask(function()
            api:shootOnce(true)
            return false
        end, 70000, 0, 1)
    end
end

return M