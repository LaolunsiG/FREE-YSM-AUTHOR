local M = {}

function M.shoot(api)
    api:safeAsyncTask(function()
        api:shootOnce(true)
        return false
    end, 5400, 0, 1)
end

return M