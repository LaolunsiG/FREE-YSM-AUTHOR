local M = {}

function M.shoot(api)
    print("shoot")
    if (api:getFireMode() == SEMI) then
        api:shootOnce(api:isShootingNeedConsumeAmmo())
    elseif (api:getFireMode() == BURST) then
        api:shootOnce(api:isShootingNeedConsumeAmmo())
        if (api:getAmmoAmount() > 0) then
            api:setAmmoInBarrel(true)
            api:removeAmmoFromMagazine(1)
        end
    end
end

function M.start_bolt(api)
    if (api:getFireMode() == SEMI) then
        return true
    elseif (api:getFireMode() == BURST) then
        return false
    end
end

return M