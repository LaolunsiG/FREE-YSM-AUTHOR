local CONSTANTS = {
    PUT_AWAY_ANIM_TIME = 0.75,
    RELOAD_ANIM_TIME = 1.8,
    BOLT_ANIM_TIME = 0.2,
    BAYONET_ANIM_TIME = 0.2,
    RUN_START_ANIM_TIME = 0.62,
    RUN_END_ANIM_TIME = 0.24,
    WALK_ANIM_TIME = 0.4,
    WALK_AIMING_ANIM_TIME = 0.3,
    IDLE_ANIM_TIME = 1.5,
    RUN_ANIM_TIME = 0.94,
    RUN_HOLD_ANIM_TIME = 0.6,
    WALK_FORWARD_ANIM_TIME = 0.4,
    WALK_BACKWARD_ANIM_TIME = 0.4,
    WALK_SIDEWAY_ANIM_TIME = 0.4,
    BAYONET_MAX_COUNTER = 3
}

local TrackManager = {
    track_line_top = {value = 0},
    static_track_top = {value = 0},
    blending_track_top = {value = 0}
}

local function increment(obj)
    obj.value = obj.value + 1
    return obj.value - 1
end

local TRACKS = {
    STATIC_TRACK_LINE = increment(TrackManager.track_line_top),
    BASE_TRACK = increment(TrackManager.static_track_top),
    BOLT_CAUGHT_TRACK = increment(TrackManager.static_track_top),
    MAIN_TRACK = increment(TrackManager.static_track_top),
    GUN_KICK_TRACK_LINE = increment(TrackManager.track_line_top),
    BLENDING_TRACK_LINE = increment(TrackManager.blending_track_top),
    MOVEMENT_TRACK = increment(TrackManager.blending_track_top),
    LOOP_TRACK = increment(TrackManager.blending_track_top),
    ADS_TRACK = increment(TrackManager.blending_track_top)
}

local AnimationUtils = {}

function AnimationUtils.runPutAwayAnimation(context)
    local put_away_time = context:getPutAwayTime()
    local track = context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK)
    context:runAnimation("put_away", track, false, PLAY_ONCE_HOLD, put_away_time * CONSTANTS.PUT_AWAY_ANIM_TIME)
    context:setAnimationProgress(track, 1, true)
    context:adjustAnimationProgress(track, -put_away_time, false)
end

function AnimationUtils.isNoAmmo(context)
    return (not context:hasBulletInBarrel()) and (context:getAmmoCount() <= 0)
end

function AnimationUtils.isLastAmmo(context)
    return context:getAmmoCount() == 1
end

function AnimationUtils.runReloadAnimation(context)
    local track = context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK)
    if AnimationUtils.isNoAmmo(context) then
        context:runAnimation("reload_empty", track, false, PLAY_ONCE_STOP, CONSTANTS.RELOAD_ANIM_TIME)
    elseif AnimationUtils.isLastAmmo(context) then
        context:runAnimation("reload_last", track, false, PLAY_ONCE_STOP, CONSTANTS.RELOAD_ANIM_TIME)
    else
        context:runAnimation("reload_tactical", track, false, PLAY_ONCE_STOP, CONSTANTS.RELOAD_ANIM_TIME)
    end
end

function AnimationUtils.runInspectAnimation(context)
    local track = context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK)
    if AnimationUtils.isNoAmmo(context) then
        context:runAnimation("inspect_empty", track, false, PLAY_ONCE_STOP, CONSTANTS.RELOAD_ANIM_TIME)
    else
        context:runAnimation("inspect", track, false, PLAY_ONCE_STOP, CONSTANTS.RELOAD_ANIM_TIME)
    end
end

local States = {}

States.base_track_state = {}
function States.base_track_state.entry(this, context)
    context:runAnimation("static_idle", context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.BASE_TRACK), false, LOOP, 0)
end

States.bolt_caught_states = {
    last = {},
    normal = {},
    bolt_caught = {}
}

function States.bolt_caught_states.normal.update(this, context)
    if AnimationUtils.isNoAmmo(context) then
        context:trigger(this.INPUT_BOLT_CAUGHT)
    elseif AnimationUtils.isLastAmmo(context) then
        context:trigger(this.INPUT_BOLT_LAST)
    end
end

function States.bolt_caught_states.last.entry(this, context)
    context:runAnimation("static_bolt_caught_last", context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.BOLT_CAUGHT_TRACK), false, LOOP, 0)
end

function States.bolt_caught_states.last.update(this, context)
    if context:getAmmoCount() > 1 then
        context:trigger(this.INPUT_BOLT_NORMAL)
    elseif AnimationUtils.isNoAmmo(context) then
        context:trigger(this.INPUT_BOLT_CAUGHT)
    end
end

function States.bolt_caught_states.last.transition(this, context, input)
    if input == this.INPUT_BOLT_CAUGHT then
        return this.bolt_caught_states.bolt_caught
    elseif input == this.INPUT_BOLT_NORMAL then
        context:stopAnimation(context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.BOLT_CAUGHT_TRACK))
        return this.bolt_caught_states.normal
    end
end

function States.bolt_caught_states.normal.entry(this, context)
    this.bolt_caught_states.normal.update(this, context)
end

function States.bolt_caught_states.normal.transition(this, context, input)
    if input == this.INPUT_BOLT_CAUGHT then
        return this.bolt_caught_states.bolt_caught
    elseif input == this.INPUT_BOLT_LAST then
        return this.bolt_caught_states.last
    end
end

function States.bolt_caught_states.bolt_caught.entry(this, context)
    context:runAnimation("static_bolt_caught", context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.BOLT_CAUGHT_TRACK), false, LOOP, 0)
end

function States.bolt_caught_states.bolt_caught.update(this, context)
    if not AnimationUtils.isNoAmmo(context) then
        context:trigger(this.INPUT_BOLT_NORMAL)
    end
end

function States.bolt_caught_states.bolt_caught.transition(this, context, input)
    if input == this.INPUT_BOLT_NORMAL then
        context:stopAnimation(context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.BOLT_CAUGHT_TRACK))
        return this.bolt_caught_states.normal
    end
end

States.ads_state = {
    aiming = {},
    not_aim = {}
}
local ads_state = States.ads_state

function ads_state.not_aim.update(this, context)
    local track = context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK)
    if context:isAiming() and context:isStopped(track) then
        context:trigger(this.INPUT_AIM_IN)
    end
end

function ads_state.not_aim.transition(this, context, input)
    if input == this.INPUT_AIM_IN then
        return this.ads_state.aiming
    end
end

function ads_state.aiming.entry(this, context)
    local track = context:getTrack(TRACKS.BLENDING_TRACK_LINE, TRACKS.ADS_TRACK)
    context:runAnimation("aim_hold", track, false, LOOP, 0.1)
end

function ads_state.aiming.update(this, context)
    local track = context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK)
    local kickTrack = context:findIdleTrack(TRACKS.GUN_KICK_TRACK_LINE, false)
    local fireMode = context:getFireMode()
    if (fireMode == SEMI or fireMode == BURST) and kickTrack then
        if not context:isStopped(kickTrack) then
            context:setTrackProgress(TRACKS.GUN_KICK_TRACK_LINE, kickTrack, 1.0, false)
        end
    end

    if not context:isStopped(track) then
        context:trigger(this.INPUT_AIM_OUT)
    elseif not context:isAiming() then
        context:trigger(this.INPUT_AIM_OUT)
    end
end

function ads_state.aiming.transition(this, context, input)
    if input == this.INPUT_SHOOT then
        return this.ads_state.aiming
    elseif input == this.INPUT_AIM_OUT then
        return this.ads_state.not_aim
    end
end

function ads_state.aiming.exit(this, context)
    local track = context:getTrack(TRACKS.BLENDING_TRACK_LINE, TRACKS.ADS_TRACK)
    context:runAnimation("aim_exit", track, true, PLAY_ONCE_STOP, 0.1)
end

States.main_track_states = {
    start = {},
    idle = {},
    inspect = {},
    final = {},
    bayonet_counter = 0
}

function States.main_track_states.start.transition(this, context, input)
    if input == INPUT_DRAW then
        context:runAnimation("draw", context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK), false, PLAY_ONCE_STOP, 0)
        return this.main_track_states.idle
    end
end

function States.main_track_states.idle.transition(this, context, input)
    if input == INPUT_PUT_AWAY then
        AnimationUtils.runPutAwayAnimation(context)
        return this.main_track_states.final
    end
    if input == INPUT_RELOAD then
        AnimationUtils.runReloadAnimation(context)
        return this.main_track_states.idle
    end
    if input == INPUT_SHOOT then
        context:popShellFrom(0)
        return this.main_track_states.idle
    end
    if input == INPUT_BOLT then
        context:runAnimation("bolt", context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK), false, PLAY_ONCE_STOP, CONSTANTS.BOLT_ANIM_TIME)
        return this.main_track_states.idle
    end
    if input == INPUT_INSPECT then
        AnimationUtils.runInspectAnimation(context)
        return this.main_track_states.inspect
    end
    if input == INPUT_BAYONET_MUZZLE then
        local counter = this.main_track_states.bayonet_counter
        local animationName = "melee_bayonet_" .. tostring(counter + 1)
        this.main_track_states.bayonet_counter = (counter + 1) % CONSTANTS.BAYONET_MAX_COUNTER
        context:runAnimation(animationName, context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK), false, PLAY_ONCE_STOP, CONSTANTS.BAYONET_ANIM_TIME)
        return this.main_track_states.idle
    end
    if input == INPUT_BAYONET_STOCK then
        context:runAnimation("melee_stock", context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK), false, PLAY_ONCE_STOP, CONSTANTS.BAYONET_ANIM_TIME)
        return this.main_track_states.idle
    end
    if input == INPUT_BAYONET_PUSH then
        context:runAnimation("melee_push", context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK), false, PLAY_ONCE_STOP, CONSTANTS.BAYONET_ANIM_TIME)
        return this.main_track_states.idle
    end
end

function States.main_track_states.inspect.entry(this, context)
    context:setShouldHideCrossHair(true)
end

function States.main_track_states.inspect.exit(this, context)
    context:setShouldHideCrossHair(false)
end

function States.main_track_states.inspect.update(this, context)
    if context:isStopped(context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK)) then
        context:trigger(this.INPUT_INSPECT_RETREAT)
    end
end

function States.main_track_states.inspect.transition(this, context, input)
    if input == this.INPUT_INSPECT_RETREAT then
        return this.main_track_states.idle
    end
    if input == INPUT_SHOOT then
        context:stopAnimation(context:getTrack(TRACKS.STATIC_TRACK_LINE, TRACKS.MAIN_TRACK))
        return this.main_track_states.idle
    end
    return this.main_track_states.idle.transition(this, context, input)
end

States.gun_kick_state = {}
function States.gun_kick_state.transition(this, context, input)
    if input == INPUT_SHOOT then
        local track = context:findIdleTrack(TRACKS.GUN_KICK_TRACK_LINE, false)
        if context:getFireMode() == SEMI then
            if context:getAmmoCount() % 2 == 0 then
                context:runAnimation("shoot_left", track, true, PLAY_ONCE_STOP, 0)
            else
                context:runAnimation("shoot_right", track, true, PLAY_ONCE_STOP, 0)
            end
        elseif context:getFireMode() == BURST then
            context:runAnimation("shoot", track, true, PLAY_ONCE_STOP, 0)
        end
    end
    return nil
end

States.movement_track_states = {
    idle = {},
    run = {
        mode = -1
    },
    walk = {
        mode = -1
    }
}

function States.movement_track_states.idle.update(this, context)
    local track = context:getTrack(TRACKS.BLENDING_TRACK_LINE, TRACKS.MOVEMENT_TRACK)
    if context:isStopped(track) or context:isHolding(track) then
        context:runAnimation("idle", track, true, LOOP, 0)
    end
end

function States.movement_track_states.idle.transition(this, context, input)
    if input == INPUT_RUN then
        return this.movement_track_states.run
    elseif input == INPUT_WALK then
        return this.movement_track_states.walk
    end
end

function States.movement_track_states.run.entry(this, context)
    this.movement_track_states.run.mode = -1
    context:runAnimation("run_start", context:getTrack(TRACKS.BLENDING_TRACK_LINE, TRACKS.MOVEMENT_TRACK), true, PLAY_ONCE_HOLD, CONSTANTS.RUN_START_ANIM_TIME)
end

function States.movement_track_states.run.exit(this, context)
    context:runAnimation("run_end", context:getTrack(TRACKS.BLENDING_TRACK_LINE, TRACKS.MOVEMENT_TRACK), true, PLAY_ONCE_HOLD, CONSTANTS.RUN_END_ANIM_TIME)
end

function States.movement_track_states.run.update(this, context)
    local track = context:getTrack(TRACKS.BLENDING_TRACK_LINE, TRACKS.MOVEMENT_TRACK)
    local state = this.movement_track_states.run;
    if context:isHolding(track) then
        context:runAnimation("run", track, true, LOOP, CONSTANTS.RUN_ANIM_TIME)
        state.mode = 0
        context:anchorWalkDist()
    end
    if state.mode ~= -1 then
        if not context:isOnGround() then
            if state.mode ~= 1 then
                state.mode = 1
                context:runAnimation("run_hold", track, true, LOOP, CONSTANTS.RUN_HOLD_ANIM_TIME)
            end
        else
            if state.mode ~= 0 then
                state.mode = 0
                context:runAnimation("run", track, true, LOOP, CONSTANTS.RUN_ANIM_TIME)
            end
            context:setAnimationProgress(track, (context:getWalkDist() % 2.0) / 2.0, true)
        end
    end
end

function States.movement_track_states.run.transition(this, context, input)
    if input == INPUT_IDLE then
        return this.movement_track_states.idle
    elseif input == INPUT_WALK then
        return this.movement_track_states.walk
    end
end

function States.movement_track_states.walk.entry(this, context)
    this.movement_track_states.walk.mode = -1
end

function States.movement_track_states.walk.exit(this, context)
    context:runAnimation("idle", context:getTrack(TRACKS.BLENDING_TRACK_LINE, TRACKS.MOVEMENT_TRACK), true, PLAY_ONCE_HOLD, CONSTANTS.IDLE_ANIM_TIME)
end

function States.movement_track_states.walk.update(this, context)
    local track = context:getTrack(TRACKS.BLENDING_TRACK_LINE, TRACKS.MOVEMENT_TRACK)
    local state = this.movement_track_states.walk
    if context:getShootCoolDown() > 0 then
        if state.mode ~= 0 then
            state.mode = 0
            context:runAnimation("idle", track, true, LOOP, CONSTANTS.IDLE_ANIM_TIME)
        end
    elseif not context:isOnGround() then
        if state.mode ~= 0 then
            state.mode = 0
            context:runAnimation("idle", track, true, LOOP, CONSTANTS.RUN_HOLD_ANIM_TIME)
        end
    elseif context:getAimingProgress() > 0.5 then
        if state.mode ~= 1 then
            state.mode = 1
            context:runAnimation("walk_aiming", track, true, LOOP, CONSTANTS.WALK_AIMING_ANIM_TIME)
        end
    elseif context:isInputUp() then
        if state.mode ~= 2 then
            state.mode = 2
            context:runAnimation("walk_forward", track, true, LOOP, CONSTANTS.WALK_FORWARD_ANIM_TIME)
            context:anchorWalkDist()
        end
    elseif context:isInputDown() then
        if state.mode ~= 3 then
            state.mode = 3
            context:runAnimation("walk_backward", track, true, LOOP, CONSTANTS.WALK_BACKWARD_ANIM_TIME)
            context:anchorWalkDist()
        end
    elseif context:isInputLeft() or context:isInputRight() then
        if state.mode ~= 4 then
            state.mode = 4
            context:runAnimation("walk_sideway", track, true, LOOP, CONSTANTS.WALK_SIDEWAY_ANIM_TIME)
            context:anchorWalkDist()
        end
    end
    if state.mode >= 1 and state.mode <= 4 then
        context:setAnimationProgress(track, (context:getWalkDist() % 2.0) / 2.0, true)
    end
end

function States.movement_track_states.walk.transition(this, context, input)
    if input == INPUT_IDLE then
        return this.movement_track_states.idle
    elseif input == INPUT_RUN then
        return this.movement_track_states.run
    end
end

local M = {
    track_line_top = TrackManager.track_line_top,
    STATIC_TRACK_LINE = TRACKS.STATIC_TRACK_LINE,
    GUN_KICK_TRACK_LINE = TRACKS.GUN_KICK_TRACK_LINE,
    BLENDING_TRACK_LINE = TRACKS.BLENDING_TRACK_LINE,
    static_track_top = TrackManager.static_track_top,
    BASE_TRACK = TRACKS.BASE_TRACK,
    BOLT_CAUGHT_TRACK = TRACKS.BOLT_CAUGHT_TRACK,
    MAIN_TRACK = TRACKS.MAIN_TRACK,
    ADS_TRACK = TRACKS.ADS_TRACK,
    blending_track_top = TrackManager.blending_track_top,
    MOVEMENT_TRACK = TRACKS.MOVEMENT_TRACK,
    LOOP_TRACK = TRACKS.LOOP_TRACK,
    base_track_state = States.base_track_state,
    bolt_caught_states = States.bolt_caught_states,
    main_track_states = States.main_track_states,
    gun_kick_state = States.gun_kick_state,
    movement_track_states = States.movement_track_states,
    ads_state = ads_state,
    INPUT_BOLT_CAUGHT = "bolt_caught",
    INPUT_BOLT_NORMAL = "bolt_normal",
    INPUT_BOLT_LAST = "bolt_last",
    INPUT_AIM_IN = "aim_in",
    INPUT_AIM_OUT = "aim_out",
    INPUT_INSPECT_RETREAT = "inspect_retreat"
}

function M:initialize(context)
    context:ensureTrackLineSize(TrackManager.track_line_top.value)
    context:ensureTracksAmount(TRACKS.STATIC_TRACK_LINE, TrackManager.static_track_top.value)
    context:ensureTracksAmount(TRACKS.BLENDING_TRACK_LINE, TrackManager.blending_track_top.value)
    self.movement_track_states.run.mode = -1
    self.movement_track_states.walk.mode = -1
end

function M:exit(context)
end

function M:states()
    return {
        self.base_track_state,
        self.bolt_caught_states.normal,
        self.main_track_states.start,
        self.gun_kick_state,
        self.movement_track_states.idle,
        self.ads_state.not_aim
    }
end

return M