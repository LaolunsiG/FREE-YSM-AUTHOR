local M = {}

function M.shoot(api)
    api:shootOnce(api:isShootingNeedConsumeAmmo())
    api:shootOnce(api:isShootingNeedConsumeAmmo())
end

return M