# DDLC_yuri

## Model Info
<details open>
<summary>Expand/Collapse</summary>

<!-- GENERATED MODEL PREVIEW README START -->

![preview01.png](previews/preview01.png)

![preview02.png](previews/preview02.png)

![preview03.png](previews/preview03.png)

<!-- GENERATED MODEL PREVIEW README END -->

- **Name**: 
- **Category**: #Game
  - **Game**: #DDLC #Doki-Doki-Literature-Club! #心跳文学部！
</details>

## Author Info
<details open>
<summary>Expand/Collapse</summary>

## Author

- **Name**: 暂无
  - **Role**: #模型 #动作 #动画 | #Model #Motion #Animation

</details>
