local M = {}

function M.calcSpread(api, num, spread)
    local cache = api:getCachedScriptData() or { melee_light_count = 0 }
    -- 基础散布强度
    local base = (0.6 + num/25)
    if (cache.melee_light_count == 0) then
        return { (((-1)^num)*num)/3 * base, 0.2 }
    elseif (cache.melee_light_count == 1) then
        return { (((-1)^num)*num)/3 * base, -0.35 }
    elseif (cache.melee_light_count == 2) then
        return {-(((-1)^num)*num)/4*base,-((-1)^num*num)/5*base}  
    elseif (cache.melee_light_count == 3) then
        return {(((-1)^num)*num)/36*base, -((-1)^num*num)/4.5*base}
    end
end

function M.shoot(api)
    -- 初始化计数器
    local cache = api:getCachedScriptData() or { melee_light_count = 0 }
    -- 重置计数器
    local last_shoot_timestamp = api:getLastShootTimestamp()
    local current_timestamp = api:getCurrentTimestamp()
    local shoot_interval = api:getShootInterval()
    if (current_timestamp - last_shoot_timestamp > shoot_interval + 300) then
        cache.melee_light_count = 0
    end
    -- 初始化射速计数器
    if (api:getShootInterval() >= 600) then
        api:adjustShootInterval(500-api:getShootInterval())
    end
    local task_config = {
        delay = 800,
        repeat_count = 0,
        priority = 1
    }
    
    -- 攻击
    if (cache.melee_light_count == 0) then
        api:safeAsyncTask(function ()
            api:shootOnce(false)
            cache.melee_light_count = 1
            return false
        end,task_config.delay,task_config.repeat_count,task_config.priority)
    elseif (cache.melee_light_count == 1) then
        api:safeAsyncTask(function ()
            api:shootOnce(false)
            cache.melee_light_count = 2
            return false
        end,task_config.delay,task_config.repeat_count,task_config.priority)
    elseif (cache.melee_light_count == 2) then
        api:safeAsyncTask(function ()
            api:shootOnce(false)
            cache.melee_light_count = 3
            return false
        end,task_config.delay,task_config.repeat_count,task_config.priority)
    elseif (cache.melee_light_count == 3) then
        api:safeAsyncTask(function ()
            api:shootOnce(false)
            cache.melee_light_count = 0
            return false
        end,task_config.delay,task_config.repeat_count,task_config.priority)
    end
    api:cacheScriptData(cache)
end

return M