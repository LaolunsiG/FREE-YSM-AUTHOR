local M = {}

function M.calcSpread(api, num, spread)
    -- 初始化计数器
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            melee_light_count = 0,
            bullet_count = 0,
            tick_limit = 0
        }
    end
    -- 根据计数器返回弹道形状
    if (api:getAttachment("GRIP") == "t80bvm:enhanced_motor") then
        if (cache.melee_light_count == 0) then
            return{(cache.bullet_count-20)/4,(cache.bullet_count-20)/10}
        elseif (cache.melee_light_count == 1) then
            return{((cache.bullet_count-20)/16),-((cache.bullet_count-20)/6)}
        elseif (cache.melee_light_count == 2) then
            return{((cache.bullet_count-20)/16),((cache.bullet_count-20)/6)}
        elseif (cache.melee_light_count == 3) then
            return{(cache.bullet_count-10)/8,(cache.bullet_count-10)/10}
        elseif (cache.melee_light_count == 4) then
            return{0,0}
        end
    else
        if (cache.melee_light_count == 0) then
            return{(cache.bullet_count-10)/2,(cache.bullet_count-10)/5}
        elseif (cache.melee_light_count == 1) then
            return{((cache.bullet_count-10)/8),-((cache.bullet_count-10)/3)}
        elseif (cache.melee_light_count == 2) then
            return{((cache.bullet_count-10)/8),((cache.bullet_count-10)/3)}
        elseif (cache.melee_light_count == 3) then
            return{(cache.bullet_count-5)/4,(cache.bullet_count-5)/5}
        elseif (cache.melee_light_count == 4) then
            return{0,0}
        end
    end

end

function M.shoot(api)
    -- 初始化计数器
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            melee_light_count = 0,
            bullet_count = 0,
            tick_limit = 0
        }
    end
    -- 重置计数器
    local last_shoot_timestamp = api:getLastShootTimestamp()
    local current_timestamp = api:getCurrentTimestamp()
    local shoot_interval = api:getShootInterval()
    if (current_timestamp - last_shoot_timestamp > shoot_interval + 800) then
        cache.melee_light_count = 0 
    end
    -- 初始化射速计数器
    -- if (api:getShootInterval() >= 800) then
    --     api:adjustShootInterval(300-api:getShootInterval())
    -- end
    -- 攻击

    if (cache.melee_light_count == 0) then
        api:safeAsyncTask(function ()
            cache.melee_light_count = 0
            cache.attack_stage = 1
            if (api:getAttachment("GRIP") == "t80bvm:enhanced_motor") then
                for i=40,0,-1 do
                    api:shootOnce(false)
                    cache.bullet_count = cache.bullet_count+1
                end 
            else
                for i=20,0,-1 do
                    api:shootOnce(false)
                    cache.bullet_count = cache.bullet_count+1
                end
            end
            cache.bullet_count = 0
            cache.melee_light_count = 1
            cache.attack_stage = 0
            -- print(cache.bullet_count)
            return false
        end,4000,0,1)

        api:adjustShootInterval(1000)
    elseif (cache.melee_light_count == 1) then
        api:safeAsyncTask(function ()
            cache.melee_light_count = 1
            if (api:getAttachment("GRIP") == "t80bvm:enhanced_motor") then
                for i=40,0,-1 do
                    api:shootOnce(false)
                    cache.bullet_count = cache.bullet_count+1
                end 
            else
                for i=20,0,-1 do
                    api:shootOnce(false)
                    cache.bullet_count = cache.bullet_count+1
                end
            end
            cache.bullet_count = 0
            cache.melee_light_count = 2
            return false
        end,4000,0,1)

        api:adjustShootInterval(1000)
    elseif (cache.melee_light_count == 2) then
         api:safeAsyncTask(function ()
            cache.melee_light_count = 2
            if (api:getAttachment("GRIP") == "t80bvm:enhanced_motor") then
                for i=40,0,-1 do
                    api:shootOnce(false)
                    cache.bullet_count = cache.bullet_count+1
                end 
            else
                for i=20,0,-1 do
                    api:shootOnce(false)
                    cache.bullet_count = cache.bullet_count+1
                end
            end
            cache.bullet_count = 0
            cache.melee_light_count = 3
            return false
        end,4000,0,1)

        api:adjustShootInterval(1000)
    elseif (cache.melee_light_count == 3) then
         api:safeAsyncTask(function ()
            cache.melee_light_count = 3
            if (api:getAttachment("GRIP") == "t80bvm:enhanced_motor") then
                for i=40,0,-1 do
                    api:shootOnce(false)
                    cache.bullet_count = cache.bullet_count+1
                end 
            else
                for i=20,0,-1 do
                    api:shootOnce(false)
                    cache.bullet_count = cache.bullet_count+1
                end
            end
            cache.bullet_count = 0
            cache.melee_light_count = 0
            return false
        end,4000,0,1)
        api:adjustShootInterval(1000)
    end
    cache.attack_stage = 0
    api:cacheScriptData(cache)
end

function M.tick_heat(api, heatTimestamp)
    local cache = api:getCachedScriptData()
    local b = 0
    if (api:getAimingProgress() >= 0.9) then
        if (cache == nil) then
            cache = {
                melee_light_count = 0,
                bullet_count = 0,
                tick_limit = 0
            }
        end
        if (cache.tick_limit == 0) then
            b = cache.melee_light_count
            cache.melee_light_count = 4
            api:shootOnce(false)
            cache.melee_light_count = b
        end
        
        cache.tick_limit = cache.tick_limit + 1
        if (api:getAttachment("GRIP") == "t80bvm:enhanced_motor") then
            if (cache.tick_limit >= 1) then
                cache.tick_limit = 0
            end
        else
            if (cache.tick_limit == 2) then
                cache.tick_limit = 0
            end
        end

        api:cacheScriptData(cache)
    end
end

return M